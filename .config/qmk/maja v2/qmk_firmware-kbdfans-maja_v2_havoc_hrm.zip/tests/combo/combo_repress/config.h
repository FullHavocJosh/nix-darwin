// Copyright 2024 @Filios92
// SPDX-License-Identifier: GPL-2.0-or-later

#pragma once

#include "test_common.h"

#define TAPPING_TERM 200

#define COMBO_PROCESS_KEY_REPRESS
